package day6.dao;


public interface WorldDao extends CountryDao, CityDao {

}
